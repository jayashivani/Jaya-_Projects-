package com.FurnitureStore.dao;

import com.FurnitureStore.model.CustomerOrder;

public interface CustomerOrderDao 

{

    void addCustomerOrder(CustomerOrder customerOrder);
}

